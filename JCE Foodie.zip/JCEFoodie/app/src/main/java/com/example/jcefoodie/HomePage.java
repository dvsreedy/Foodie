package com.example.jcefoodie;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Toast;

public class HomePage extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_page);
    }
    public void sandwichClick (View view) {
        Intent intent = new Intent(this, RankPage.class);
        intent.putExtra("foodItem", "Sandwich");
        startActivity(intent);
    }
    public void oreoClick (View view) {
        Intent intent = new Intent(this, RankPage.class);
        intent.putExtra("foodItem", "Oreo Shake");
        startActivity(intent);
    }
    public void samosaClick (View view) {
        Intent intent = new Intent(this, RankPage.class);
        intent.putExtra("foodItem", "Samosa");
        startActivity(intent);
    }
    public void teaClick (View view) {
        Intent intent = new Intent(this, RankPage.class);
        intent.putExtra("foodItem", "Coffee");
        startActivity(intent);
    }
    public void gobiClick (View view) {
        Intent intent = new Intent(this, RankPage.class);
        intent.putExtra("foodItem", "Gobi Manchurian");
        startActivity(intent);
    }
    public void mealClick (View view) {
        Intent intent = new Intent(this, RankPage.class);
        intent.putExtra("foodItem", "Meal");
        startActivity(intent);
    }
    public void noodlesClick (View view) {
        Intent intent = new Intent(this, RankPage.class);
        intent.putExtra("foodItem", "Noodles");
        startActivity(intent);
    }
    public void burgerClick (View view) {
        Intent intent = new Intent(this, RankPage.class);
        intent.putExtra("foodItem", "Burger");
        startActivity(intent);
    }
    private Boolean exit = false;
    public void onBackPressed() {
        if (exit) {
            moveTaskToBack(true); // finish activity
        } else {
            Toast.makeText(this, "Press Back again to Exit.", Toast.LENGTH_SHORT).show();
            exit = true;
            new Handler().postDelayed(new Runnable() {
                @Override
                public void run() {
                    exit = false;
                }
            }, 3 * 1000);
        }
    }
}