package com.example.jcefoodie;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class RankPage extends AppCompatActivity {

    boolean rank1 = true, rank2 = true, rank3 = true;
    int count = 0;
    int[] ratings = new int[4];
    String foodItem, text, loc1, loc2, loc3, loc4;
    String[] restaurants = new String[4];

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rank_page);
        Intent intent = getIntent();
        foodItem = intent.getStringExtra("foodItem");
        TextView textView = findViewById(R.id.textView5);
        text = "Popular Places in JCE for " + foodItem;
        textView.setText(text);
        DatabaseReference reference = FirebaseDatabase.getInstance().getReference(foodItem);
        reference.orderByChild("rate").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                    if (rank1) {
                        TextView textView = findViewById(R.id.textView1);
                        text = "1. "+snapshot.getKey() +"\nPreparation Time: " +snapshot.child("prepTime").getValue()+" minutes\nPrice: Rs." +snapshot.child("price").getValue();
                        textView.setText(text);
                        rank1 = false;
                        ImageButton button = findViewById(R.id.imageButton1);
                        button.setBackgroundResource(R.drawable.map_pointer);
                        loc1 = snapshot.child("gmapLink").getValue(String.class);
                    } else if (rank2) {
                        TextView textView = findViewById(R.id.textView2);
                        text = "2. "+snapshot.getKey() +"\nPreparation Time: " +snapshot.child("prepTime").getValue()+" minutes\nPrice: Rs." +snapshot.child("price").getValue();
                        textView.setText(text);
                        rank2 = false;
                        ImageButton button = findViewById(R.id.imageButton2);
                        button.setBackgroundResource(R.drawable.map_pointer);
                        loc2 = snapshot.child("gmapLink").getValue(String.class);
                    } else if (rank3) {
                        TextView textView = findViewById(R.id.textView3);
                        text = "3. "+snapshot.getKey() +"\nPreparation Time: " +snapshot.child("prepTime").getValue()+" minutes\nPrice: Rs." +snapshot.child("price").getValue();
                        textView.setText(text);
                        rank3 = false;
                        ImageButton button = findViewById(R.id.imageButton3);
                        button.setBackgroundResource(R.drawable.map_pointer);
                        loc3 = snapshot.child("gmapLink").getValue(String.class);
                    } else {
                        TextView textView = findViewById(R.id.textView4);
                        loc4 = snapshot.child("gmapLink").getValue(String.class);
                        text = "4. "+snapshot.getKey() +"\nPreparation Time: " +snapshot.child("prepTime").getValue()+" minutes\nPrice: Rs." +snapshot.child("price").getValue();
                        textView.setText(text);
                        ImageButton button = findViewById(R.id.imageButton4);
                        button.setBackgroundResource(R.drawable.map_pointer);
                    }
                    ratings[count] = snapshot.child("rate").getValue(int.class);
                    restaurants[count++] = snapshot.getKey();
                }
            }
            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    public void gotoRatePage (View view) {
        Intent intent = new Intent(this, RatePage.class);
        intent.putExtra("foodItem", foodItem);
        intent.putExtra("count", count);
        intent.putExtra("restaurants", restaurants);
        intent.putExtra("ratings", ratings);
        startActivity(intent);
        finish();
    }

    public void r1 (View view) {
        Uri uri = Uri.parse(loc1);
        Intent intent = new Intent(Intent.ACTION_VIEW, uri);
        startActivity(intent);
    }
    public void r2 (View view) {
        Uri uri = Uri.parse(loc2);
        Intent intent = new Intent(Intent.ACTION_VIEW, uri);
        startActivity(intent);
    }
    public void r3 (View view) {
        Uri ri = Uri.parse(loc3);
        Intent intent = new Intent(Intent.ACTION_VIEW, ri);
        startActivity(intent);
    }
    public void r4 (View view) {
        Uri ri = Uri.parse(loc4);
        Intent intent = new Intent(Intent.ACTION_VIEW, ri);
        startActivity(intent);
    }
}