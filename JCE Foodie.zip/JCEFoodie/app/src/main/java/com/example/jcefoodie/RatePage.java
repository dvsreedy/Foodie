package com.example.jcefoodie;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Parcelable;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;

public class RatePage extends AppCompatActivity {

    int count, n1, n2;
    String[] restaurants;
    int[] ratings;
    String foodItem;
    int rate;
    DatabaseReference reference;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rate_page);
        Intent intent = getIntent();
        foodItem = intent.getStringExtra("foodItem");
        count = intent.getIntExtra("count",100);
        restaurants = intent.getStringArrayExtra("restaurants");
        ratings = intent.getIntArrayExtra("ratings");
        reference = FirebaseDatabase.getInstance().getReference(foodItem);
        TextView textView = findViewById(R.id.textView6);
        textView.setText("Pick your favourite place for " + foodItem);
        Random random = new Random();
        n1 = random.nextInt(count);
        n2 = random.nextInt(count);
        while (n1 == n2) {
            n2 = random.nextInt(count);
        }
        Button button = findViewById(R.id.button1);
        button.setText(restaurants[n1]);
        button = findViewById(R.id.button2);
        button.setText(restaurants[n2]);
    }

    public void randomizer (View view) {
        Random random = new Random();
        n1 = random.nextInt(count);
        n2 = random.nextInt(count);
        while (n1 == n2) {
            n2 = random.nextInt(count);
        }
        Button button = findViewById(R.id.button1);
        button.setText(restaurants[n1]);
        button = findViewById(R.id.button2);
        button.setText(restaurants[n2]);
    }

    public  void button1 (View view) {
        String restaurant = restaurants[n1];
        reference.child(restaurant).child("rate").setValue(ratings[n1]-1);
        Toast.makeText(this, "Thank You!", Toast.LENGTH_LONG).show();
        finish();
    }

    public  void button2 (View view) {
        String restaurant = restaurants[n1];
        reference.child(restaurant).child("rate").setValue(ratings[n1] - 1);
        Toast.makeText(this, "Thank You!", Toast.LENGTH_LONG).show();
        finish();
    }
}